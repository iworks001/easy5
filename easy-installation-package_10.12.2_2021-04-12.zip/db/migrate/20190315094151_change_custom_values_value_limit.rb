class ChangeCustomValuesValueLimit < ActiveRecord::Migration[5.2]
end
