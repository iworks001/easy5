# frozen_string_literal: true

# Add new mime types for use in respond_to blocks:
